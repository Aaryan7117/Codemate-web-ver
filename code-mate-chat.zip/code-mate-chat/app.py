from flask import Flask, request, jsonify, render_template
import subprocess
import json
import os
import logging
from datetime import datetime

app = Flask(__name__)

LOG_FILE = "app.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

FEEDBACK_FILE = "feedback.json"
CHAT_HISTORY_DIR = "chat_history"

os.makedirs(CHAT_HISTORY_DIR, exist_ok=True)

def load_json_file(file_path):
    """Safely load JSON data from a file."""
    try:
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as file:
                return json.load(file)
        return []
    except json.JSONDecodeError:
        logger.error(f"Corrupt JSON file: {file_path}. Resetting file.")
        return []
    except Exception as e:
        logger.error(f"Error loading {file_path}: {str(e)}")
        return []

def save_json_file(file_path, data):
    """Safely save JSON data to a file."""
    try:
        with open(file_path, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        logger.error(f"Error saving {file_path}: {str(e)}")
        return False

def save_feedback(query, response, rating):
    """Save user feedback (query, response, rating) to a JSON file."""
    feedback_data = load_json_file(FEEDBACK_FILE)
    feedback_data.append({
        "query": query,
        "response": response,
        "rating": rating,
        "timestamp": datetime.now().isoformat()
    })
    return save_json_file(FEEDBACK_FILE, feedback_data)

def save_chat_message(chat_id, role, content):
    """Save a chat message to the chat history."""
    chat_file = os.path.join(CHAT_HISTORY_DIR, f"{chat_id}.json")
    chat_data = load_json_file(chat_file)
    chat_data.append({
        "role": role,
        "content": content,
        "timestamp": datetime.now().isoformat()
    })
    return save_json_file(chat_file, chat_data)

@app.route("/")
def index():
    """Render the main application page."""
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    """Process user query and return AI response."""
    try:
        data = request.json
        query = data.get("query", "").strip()
        chat_id = data.get("chat_id", "default")

        if not query:
            return jsonify({"response": "Error: Empty query received"}), 400

        save_chat_message(chat_id, "user", query)

        result = subprocess.run(
            ["ollama", "run", "llama3.2"], 
            input=query,
            capture_output=True,
            text=True
        )



        response = result.stdout.strip() or "Sorry, I couldn't process your request."
        save_chat_message(chat_id, "assistant", response)

        return jsonify({"response": response})

    except Exception as e:
        return jsonify({"response": f"Error: {str(e)}"}), 500

@app.route("/submit_feedback", methods=["POST"])
def submit_feedback():
    """Receive user feedback and store it."""
    try:
        data = request.json
        query, response, rating = data.get("query"), data.get("response"), data.get("rating")

        if query and response and rating is not None:
            if save_feedback(query, response, rating):
                return jsonify({"message": "Feedback saved successfully!"})
            return jsonify({"error": "Failed to save feedback"}), 500

        return jsonify({"error": "Invalid feedback data"}), 400

    except Exception as e:
        return jsonify({"error": f"Error processing feedback: {str(e)}"}), 500

@app.route("/chat/<chat_id>", methods=["GET"])
def get_chat(chat_id):
    """Get chat history for a specific chat ID."""
    chat_file = os.path.join(CHAT_HISTORY_DIR, f"{chat_id}.json")
    chat_data = load_json_file(chat_file)

    if not chat_data:
        return jsonify({"error": "Chat not found"}), 404

    return jsonify({"chat_id": chat_id, "messages": chat_data})

@app.route("/chats", methods=["GET"])
def get_chats():
    """Get list of all chat IDs."""
    try:
        chat_files = [f for f in os.listdir(CHAT_HISTORY_DIR) if f.endswith(".json")]
        chats = []

        for chat_file in chat_files:
            chat_id = os.path.splitext(chat_file)[0]
            chat_data = load_json_file(os.path.join(CHAT_HISTORY_DIR, chat_file))

            title = "New Chat"
            for message in chat_data:
                if message["role"] == "user":
                    title = message["content"][:30] + "..." if len(message["content"]) > 30 else message["content"]
                    break

            latest_timestamp = chat_data[-1]["timestamp"] if chat_data else None
            chats.append({"id": chat_id, "title": title, "updated_at": latest_timestamp})

        chats.sort(key=lambda x: x["updated_at"] or "", reverse=True)

        return jsonify({"chats": chats})

    except Exception as e:
        return jsonify({"error": f"Error retrieving chats: {str(e)}"}), 500

@app.route("/chat/<chat_id>", methods=["DELETE"])
def delete_chat(chat_id):
    """Delete a chat."""
    chat_file = os.path.join(CHAT_HISTORY_DIR, f"{chat_id}.json")

    if os.path.exists(chat_file):
        os.remove(chat_file)
        return jsonify({"message": "Chat deleted successfully"})

    return jsonify({"error": "Chat not found"}), 404

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8000)
