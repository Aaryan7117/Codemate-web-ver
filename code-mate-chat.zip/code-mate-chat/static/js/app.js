// Initialize Firebase Configuration
const firebaseConfig = {
  apiKey: "YOUR_API_KEY", // Replace with your Firebase API key in production
  authDomain: "codemate-ai.firebaseapp.com",
  projectId: "codemate-ai",
  storageBucket: "codemate-ai.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:1234567890abcdef",
}

// Initialize Firebase
const firebase = window.firebase // Declare firebase variable
firebase.initializeApp(firebaseConfig)
const auth = firebase.auth()
const db = firebase.firestore()

// App State
const state = {
  currentChatId: generateUUID(),
  messages: [],
  user: null,
  isTyping: false,
  darkMode: localStorage.getItem("darkMode") === "true",
  theme: localStorage.getItem("theme") || "blue",
  fontSize: Number.parseFloat(localStorage.getItem("fontSize")) || 16,
  ttsEnabled: localStorage.getItem("ttsEnabled") === "true",
  ttsSpeed: Number.parseFloat(localStorage.getItem("ttsSpeed")) || 1,
  ttsPitch: Number.parseFloat(localStorage.getItem("ttsPitch")) || 1,
  speech: null,
  isListening: false,
  recognitionActive: false,
  compactMode: localStorage.getItem("compactMode") === "true",
  animationsEnabled: localStorage.getItem("animationsEnabled") !== "false",
  recognition: null,
  speechSynthesis: window.speechSynthesis,
  voices: [],
  selectedVoice: localStorage.getItem("selectedVoice") || "",
  fileList: [],
  currentChat: {
    title: "New Chat",
    updatedAt: new Date().toISOString(),
  },
}

// DOM Elements
const elements = {
  app: document.getElementById("app"),
  sidebar: document.querySelector(".sidebar"),
  toggleSidebarBtn: document.querySelector(".toggle-sidebar-btn"),
  userInput: document.getElementById("user-input"),
  sendBtn: document.getElementById("send-btn"),
  messagesContainer: document.getElementById("messages-container"),
  newChatBtn: document.getElementById("new-chat-btn"),
  chatHistory: document.getElementById("chat-history"),
  recentChats: document.getElementById("recent-chats"),
  todayChats: document.getElementById("today-chats"),
  weekChats: document.getElementById("week-chats"),
  themeToggle: document.getElementById("theme-toggle"),
  userProfile: document.getElementById("user-profile"),
  userMenuBtn: document.querySelector(".user-menu-btn"),
  userDropdown: document.querySelector(".user-dropdown"),
  voiceBtn: document.getElementById("voice-btn"),
  uploadBtn: document.getElementById("upload-btn"),
  ttsToggle: document.getElementById("tts-toggle"),
  ttsSpeedContainer: document.getElementById("tts-speed-container"),
  ttsSpeed: document.getElementById("tts-speed"),
  ttsSpeedValue: document.getElementById("tts-speed-value"),
  shareBtn: document.getElementById("share-btn"),
  clearContextBtn: document.getElementById("clear-context-btn"),
  settingsBtn: document.getElementById("settings-btn"),
  exportBtn: document.getElementById("export-btn"),
  loginBtn: document.getElementById("login-btn"),
  signupBtn: document.getElementById("signup-btn"),
  logoutBtn: document.getElementById("logout-btn"),
  fileModal: document.getElementById("file-modal"),
  settingsModal: document.getElementById("settings-modal"),
  shareModal: document.getElementById("share-modal"),
  exportModal: document.getElementById("export-modal"),
  closeModalBtns: document.querySelectorAll(".close-modal-btn"),
  toastContainer: document.getElementById("toast-container"),
  fileDropArea: document.querySelector(".file-drop-area"),
  fileInput: document.querySelector(".file-input"),
  fileList: document.querySelector(".file-list"),
  confirmUploadBtn: document.querySelector(".confirm-upload-btn"),
  cancelUploadBtn: document.querySelector(".cancel-upload-btn"),
  darkModeToggle: document.getElementById("dark-mode-toggle"),
  colorThemes: document.querySelectorAll(".color-theme"),
  fontSizeIncrease: document.getElementById("font-size-increase"),
  fontSizeDecrease: document.getElementById("font-size-decrease"),
  fontSizeReset: document.getElementById("font-size-reset"),
  animationsToggle: document.getElementById("animations-toggle"),
  compactModeToggle: document.getElementById("compact-mode-toggle"),
  ttsEnabledToggle: document.getElementById("tts-enabled-toggle"),
  ttsVoiceSelect: document.getElementById("tts-voice-select"),
  ttsSpeedSetting: document.getElementById("tts-speed-setting"),
  ttsSpeedSettingValue: document.getElementById("tts-speed-setting-value"),
  ttsPitch: document.getElementById("tts-pitch"),
  ttsPitchValue: document.getElementById("tts-pitch-value"),
  voiceInputToggle: document.getElementById("voice-input-toggle"),
  voiceLanguageSelect: document.getElementById("voice-language-select"),
  voiceAutoSendToggle: document.getElementById("voice-auto-send-toggle"),
  settingsTabs: document.querySelectorAll(".settings-tab"),
  settingsPanels: document.querySelectorAll(".settings-panel"),
  shareLink: document.getElementById("share-link-input"),
  copyShareLink: document.getElementById("copy-share-link"),
  shareSocial: document.querySelectorAll(".share-option"),
  exportOptions: document.querySelectorAll(".export-option"),
  exportChatSelect: document.getElementById("export-chat-select"),
  exportIncludeCode: document.getElementById("export-include-code"),
  confirmExportBtn: document.querySelector(".confirm-export-btn"),
  cancelExportBtn: document.querySelector(".cancel-export-btn"),
  clearDataBtn: document.getElementById("clear-data-btn"),
  suggestionChips: document.querySelectorAll(".suggestion-chip"),
}

// Helper Functions
function generateUUID() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === "x" ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

function formatTimestamp(timestamp) {
  const date = new Date(timestamp)
  const now = new Date()
  const diffInDays = Math.floor((now - date) / (1000 * 60 * 60 * 24))

  if (diffInDays === 0) {
    return `Today at ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
  } else if (diffInDays === 1) {
    return `Yesterday at ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
  } else {
    return date.toLocaleDateString([], { month: "short", day: "numeric" })
  }
}

function showToast(title, message, type = "info") {
  const toast = document.createElement("div")
  toast.className = `toast toast-${type}`
  toast.innerHTML = `
    <div class="toast-icon">
      ${
        type === "success"
          ? '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>'
          : type === "error"
            ? '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>'
            : type === "warning"
              ? '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>'
              : '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>'
      }
    </div>
    <div class="toast-content">
      <div class="toast-title">${title}</div>
      <div class="toast-message">${message}</div>
    </div>
    <button class="toast-close">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
    </button>
  `

  elements.toastContainer.appendChild(toast)

  // Set up close button
  const closeBtn = toast.querySelector(".toast-close")
  closeBtn.addEventListener("click", () => {
    elements.toastContainer.removeChild(toast)
  })

  // Auto-remove after 3 seconds
  setTimeout(() => {
    if (elements.toastContainer.contains(toast)) {
      elements.toastContainer.removeChild(toast)
    }
  }, 3000)
}

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function parseCodeBlocks(text) {
  text = text.replace(/```(\w+)?\n([\s\S]*?)\n```/g, (match, language, code) => {
    language = language || "plaintext";

    const escapedCode = escapeHtml(code)
      .replace(/\n/g, "&#10;")  

    return `
      <div class="code-container">
        <div class="code-header">
          <span class="language-tag">${language}</span>
          <div class="code-header-actions">
            <button class="run-code-btn" data-language="${language}">Run</button>
            <button class="copy-btn">Copy</button>
          </div>
        </div>
        <pre><code class="code-block language-${language}">${escapedCode}</code></pre>
        <pre class="code-output"></pre>
      </div>
    `;
  });

  // Replace inline code with formatted HTML
  text = text.replace(/`([^`]+)`/g, "<code>$1</code>");

  return text;
}


// Format message content with markdown-like syntax
function formatMessageContent(text) {
  // First handle code blocks
  text = parseCodeBlocks(text);

  // Basic markdown formatting
  text = text
    // Bold
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    // Italic
    .replace(/\*(.*?)\*/g, "<em>$1</em>")
    // Links (fixed regex)
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
    // Headers (h3 only for messages)
    .replace(/^### (.*$)/gm, "<h3>$1</h3>")
    // Unordered lists
    .replace(/^\s*-\s(.*$)/gm, "<li>$1</li>")
    // Ordered lists (with numbers)
    .replace(/^\s*\d+\.\s(.*$)/gm, "<li>$1</li>");

  // Wrap lists in ul/ol tags
  text = text.replace(/<li>(.*?)<\/li>/g, "<ul><li>$1</li></ul>");
  // Combine consecutive ul tags
  text = text.replace(/<\/ul>\s*<ul>/g, "");

  // Convert line breaks to paragraphs
  const paragraphs = text.split(/\n\s*\n/);
  text = paragraphs
    .map((para) => {
      // Skip if paragraph already contains HTML tags
      if (para.trim().startsWith("<") && !para.trim().startsWith("<li>")) {
        return para;
      }
      return `<p>${para.replace(/\n/g, "<br>")}</p>`;
    })
    .join("");

  // Ensure chat remains visible after formatting
  setTimeout(ensureChatVisibility, 100);

  return text;
}



// API Functions
async function sendMessage(message) {
  try {
    const response = await fetch("/ask", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: message,
        chat_id: state.currentChatId,
      }),
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return data.response
  } catch (error) {
    console.error("Error sending message:", error)
    showToast("Error", "Failed to send message. Please try again.", "error")
    return "Sorry, there was an error processing your request."
  }
}

async function fetchChats() {
  try {
    const response = await fetch("/chats")

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return data.chats
  } catch (error) {
    console.error("Error fetching chats:", error)
    showToast("Error", "Failed to load chat history.", "error")
    return []
  }
}

async function fetchChatMessages(chatId) {
  try {
    const response = await fetch(`/chat/${chatId}`)

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return data.messages
  } catch (error) {
    console.error("Error fetching chat messages:", error)
    showToast("Error", "Failed to load chat messages.", "error")
    return []
  }
}

async function deleteChat(chatId) {
  try {
    const response = await fetch(`/chat/${chatId}`, {
      method: "DELETE",
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    return true
  } catch (error) {
    console.error("Error deleting chat:", error)
    showToast("Error", "Failed to delete chat.", "error")
    return false
  }
}

async function submitFeedback(query, response, rating) {
  try {
    const responseData = await fetch("/submit_feedback", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ query, response, rating }),
    })

    if (!responseData.ok) {
      throw new Error(`HTTP error! status: ${responseData.status}`)
    }

    return true
  } catch (error) {
    console.error("Error submitting feedback:", error)
    return false
  }
}

// UI Update Functions
function updateChatHistory(chats) {
  // Clear existing history
  elements.recentChats.innerHTML = ""
  elements.todayChats.innerHTML = ""
  elements.weekChats.innerHTML = ""

  if (!chats || chats.length === 0) {
    return
  }

  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime()
  const oneWeekAgo = today - 7 * 24 * 60 * 60 * 1000

  chats.forEach((chat) => {
    const chatDate = chat.updated_at ? new Date(chat.updated_at).getTime() : 0
    const chatEl = createChatHistoryItem(chat)

    // Add to appropriate section
    if (chatDate >= today) {
      elements.todayChats.appendChild(chatEl)
    } else if (chatDate >= oneWeekAgo) {
      elements.weekChats.appendChild(chatEl)
    } else {
      elements.recentChats.appendChild(chatEl)
    }
  })
}

function createChatHistoryItem(chat) {
  const chatEl = document.createElement("div")
  chatEl.className = `history-item ${chat.id === state.currentChatId ? "active" : ""}`
  chatEl.dataset.chatId = chat.id

  chatEl.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
    </svg>
    <div class="history-item-title">${chat.title}</div>
    <button class="delete-chat-btn" data-chat-id="${chat.id}">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 6h18"></path>
        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
      </svg>
    </button>
  `

  // Add event listener to switch to this chat
  chatEl.addEventListener("click", (e) => {
    if (!e.target.closest(".delete-chat-btn")) {
      loadChat(chat.id)
    }
  })

  // Add event listener for delete button
  const deleteBtn = chatEl.querySelector(".delete-chat-btn")
  deleteBtn.addEventListener("click", async (e) => {
    e.stopPropagation()
    const success = await deleteChat(chat.id)
    if (success) {
      showToast("Success", "Chat deleted successfully.", "success")
      loadChatHistory()

      // If deleted current chat, start a new one
      if (chat.id === state.currentChatId) {
        startNewChat()
      }
    }
  })

  return chatEl
}

async function loadChat(chatId) {
  try {
    const messages = await fetchChatMessages(chatId)

    if (messages.length === 0) {
      showToast("Error", "Chat not found.", "error")
      return false
    }

    // Update state
    state.currentChatId = chatId
    state.messages = messages

    // Update UI
    renderMessages()

    // Update active chat in sidebar
    const activeChat = document.querySelector(".history-item.active")
    if (activeChat) {
      activeChat.classList.remove("active")
    }

    const newActiveChat = document.querySelector(`.history-item[data-chat-id="${chatId}"]`)
    if (newActiveChat) {
      newActiveChat.classList.add("active")
    }

    // Update chat title
    let title = "New Chat"
    for (const message of messages) {
      if (message.role === "user") {
        title = message.content.substring(0, 30)
        if (message.content.length > 30) title += "..."
        break
      }
    }

    document.querySelector(".chat-title").textContent = title

    return true
  } catch (error) {
    console.error("Error loading chat:", error)
    showToast("Error", "Failed to load chat.", "error")
    return false
  }
}

function renderMessages() {
  // Clear messages container
  elements.messagesContainer.innerHTML = ""

  if (state.messages.length === 0) {
    // Show welcome message
    elements.messagesContainer.innerHTML = `
      <div class="welcome-message">
        <div class="welcome-header">
          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="welcome-icon">
            <path d="m18 16 4-4-4-4"></path>
            <path d="m6 8-4 4 4 4"></path>
            <path d="m14.5 4-5 16"></path>
          </svg>
          <h2>Welcome to CodeMate AI</h2>
          <p>Your intelligent coding assistant powered by advanced language models</p>
        </div>
        <div class="features-grid">
          <div class="feature-card">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <line x1="16" y1="13" x2="8" y2="13"></line>
              <line x1="16" y1="17" x2="8" y2="17"></line>
              <line x1="10" y1="9" x2="8" y2="9"></line>
            </svg>
            <h3>Code Generation</h3>
            <p>Generate code snippets in multiple programming languages</p>
          </div>
          <div class="feature-card">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m18 16 4-4-4-4"></path>
              <path d="m6 8-4 4 4 4"></path>
              <path d="m14.5 4-5 16"></path>
            </svg>
            <h3>Code Explanation</h3>
            <p>Get detailed explanations of complex code</p>
          </div>
          <div class="feature-card">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M2 12h10"></path>
              <path d="M9 4v16"></path>
              <path d="m3 9 3 3-3 3"></path>
              <path d="M14 8l6 8"></path>
              <path d="M14 16l6-8"></path>
            </svg>
            <h3>Debugging Help</h3>
            <p>Find and fix bugs in your code with AI assistance</p>
          </div>
          <div class="feature-card">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 20h9"></path>
              <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
            </svg>
            <h3>Code Refactoring</h3>
            <p>Improve your code quality and performance</p>
          </div>
        </div>
        <div class="suggestion-chips">
          <button class="suggestion-chip">Generate a Python function to sort a list</button>
          <button class="suggestion-chip">Explain React useEffect hook</button>
          <button class="suggestion-chip">Debug my JavaScript code</button>
          <button class="suggestion-chip">Create a Flask REST API</button>
        </div>
      </div>
    `

    // Add event listeners to suggestion chips
    document.querySelectorAll(".suggestion-chip").forEach((chip) => {
      chip.addEventListener("click", () => {
        elements.userInput.value = chip.textContent
        elements.userInput.focus()
      })
    })

    return
  }

  // Add each message
  state.messages.forEach((message, index) => {
    const messageEl = document.createElement("div")
    messageEl.className = `message message-${message.role === "user" ? "user" : "ai"}`

    const formattedContent = formatMessageContent(message.content)

    messageEl.innerHTML = `
      <div class="message-content">${formattedContent}</div>
    `

    // Add feedback buttons for AI messages only
    if (message.role === "assistant") {
      const feedbackContainer = document.createElement("div")
      feedbackContainer.className = "feedback-container"
      feedbackContainer.innerHTML = `
        <button class="feedback-btn positive" aria-label="Thumbs up">👍</button>
        <button class="feedback-btn negative" aria-label="Thumbs down">👎</button>
      `

      // Add event listeners to feedback buttons
      const positiveBtn = feedbackContainer.querySelector(".positive")
      const negativeBtn = feedbackContainer.querySelector(".negative")

      positiveBtn.addEventListener("click", () => {
        handleFeedback(index, 1)
        positiveBtn.classList.add("active")
        negativeBtn.classList.remove("active")

        // Show thank you message
        const thankYouEl = document.createElement("div")
        thankYouEl.className = "feedback-thank-you"
        thankYouEl.textContent = "Thanks for your feedback!"
        feedbackContainer.appendChild(thankYouEl)
      })

      negativeBtn.addEventListener("click", () => {
        handleFeedback(index, -1)
        negativeBtn.classList.add("active")
        positiveBtn.classList.remove("active")

        // Show thank you message
        const thankYouEl = document.createElement("div")
        thankYouEl.className = "feedback-thank-you"
        thankYouEl.textContent = "Thanks for your feedback!"
        feedbackContainer.appendChild(thankYouEl)
      })

      messageEl.appendChild(feedbackContainer)
    }

    elements.messagesContainer.appendChild(messageEl)
  })

  // Add code highlighting and copy buttons
  setupCodeBlocks()

  // Scroll to bottom
  elements.messagesContainer.scrollTop = elements.messagesContainer.scrollHeight
}

function setupCodeBlocks() {
  // Apply syntax highlighting
  document.querySelectorAll("pre code").forEach((block) => {
    hljs.highlightElement(block)
  })

  // Set up copy buttons
  document.querySelectorAll(".copy-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const codeBlock = button.closest(".code-container").querySelector("code")
      const code = codeBlock.textContent

      navigator.clipboard.writeText(code).then(() => {
        button.textContent = "Copied!"
        button.classList.add("copied")

        setTimeout(() => {
          button.textContent = "Copy"
          button.classList.remove("copied")
        }, 2000)
      })
    })
  })

  // Set up run code buttons
  document.querySelectorAll(".run-code-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const codeContainer = button.closest(".code-container")
      const codeBlock = codeContainer.querySelector("code")
      const outputBlock = codeContainer.querySelector(".code-output")
      const language = button.dataset.language
      const code = codeBlock.textContent

      // Show output block
      outputBlock.style.display = "block"
      outputBlock.textContent = "Running..."

      // For demonstration, we'll only support JavaScript execution in the browser
      if (language === "javascript" || language === "js") {
        try {
          // Create a safe evaluation environment
          const originalConsoleLog = console.log
          let output = ""

          // Override console.log to capture output
          console.log = (...args) => {
            output += args.map((arg) => (typeof arg === "object" ? JSON.stringify(arg, null, 2) : arg)).join(" ") + "\n"
            originalConsoleLog(...args)
          }

          // Execute the code
          eval(code)

          // Restore console.log
          console.log = originalConsoleLog

          // Display output
          outputBlock.textContent = output || "Code executed successfully with no output."
        } catch (error) {
          outputBlock.textContent = `Error: ${error.message}`
        }
      } else {
        outputBlock.textContent = `Running code in ${language} is not supported in the browser.`
      }
    })
  })
}

// Add a function to ensure chat persistence after code blocks are added
// Add this function after the setupCodeBlocks function

function ensureChatVisibility() {
  // Make sure the chat container is visible
  elements.messagesContainer.style.display = "flex"

  // Ensure proper scrolling
  setTimeout(() => {
    elements.messagesContainer.scrollTop = elements.messagesContainer.scrollHeight
  }, 200)
}

async function handleFeedback(messageIndex, rating) {
  if (messageIndex <= 0 || messageIndex >= state.messages.length) {
    return
  }

  const userMessage = state.messages[messageIndex - 1]
  const aiMessage = state.messages[messageIndex]

  if (userMessage.role !== "user" || aiMessage.role !== "assistant") {
    return
  }

  await submitFeedback(userMessage.content, aiMessage.content, rating)
}

function startNewChat() {
  // Generate new chat ID
  state.currentChatId = generateUUID()

  // Reset messages
  state.messages = []

  // Update UI
  renderMessages()
  document.querySelector(".chat-title").textContent = "New Chat"

  // Update active chat in sidebar
  const activeChat = document.querySelector(".history-item.active")
  if (activeChat) {
    activeChat.classList.remove("active")
  }
}

function showTypingIndicator() {
  const typingIndicator = document.createElement("div")
  typingIndicator.className = "typing-indicator"
  typingIndicator.innerHTML = `
    <span></span>
    <span></span>
    <span></span>
  `

  elements.messagesContainer.appendChild(typingIndicator)
  elements.messagesContainer.scrollTop = elements.messagesContainer.scrollHeight

  state.isTyping = true
}

function removeTypingIndicator() {
  const typingIndicator = document.querySelector(".typing-indicator")
  if (typingIndicator) {
    typingIndicator.remove()
  }

  state.isTyping = false
}

// Initialize Web Speech API for voice input
function initSpeechRecognition() {
  if ("SpeechRecognition" in window || "webkitSpeechRecognition" in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    state.recognition = new SpeechRecognition()
    state.recognition.continuous = true
    state.recognition.interimResults = true

    state.recognition.onstart = () => {
      state.isListening = true
      elements.voiceBtn.classList.add("listening")
    }

    state.recognition.onend = () => {
      state.isListening = false
      elements.voiceBtn.classList.remove("listening")
    }

    state.recognition.onresult = (event) => {
      const transcript = Array.from(event.results)
        .map((result) => result[0])
        .map((result) => result.transcript)
        .join("")

      elements.userInput.value = transcript
      elements.sendBtn.disabled = !transcript.trim()

      // Auto-send if enabled and we have a final result
      const isFinal = event.results[0].isFinal
      if (isFinal && elements.voiceAutoSendToggle.checked && transcript.trim()) {
        handleSendMessage()
      }
    }

    state.recognition.onerror = (event) => {
      console.error("Speech recognition error", event.error)
      state.isListening = false
      elements.voiceBtn.classList.remove("listening")

      if (event.error === "not-allowed") {
        showToast("Error", "Microphone access denied. Please check your browser settings.", "error")
      }
    }
  } else {
    elements.voiceBtn.style.display = "none"
    elements.voiceInputToggle.parentElement.parentElement.style.display = "none"
  }
}

// Initialize Text-to-Speech
function initTextToSpeech() {
  if ("speechSynthesis" in window) {
    // Load available voices
    const loadVoices = () => {
      state.voices = state.speechSynthesis.getVoices()

      // Populate voice select dropdown
      elements.ttsVoiceSelect.innerHTML = ""
      state.voices.forEach((voice, index) => {
        const option = document.createElement("option")
        option.value = index
        option.textContent = `${voice.name} (${voice.lang})`
        elements.ttsVoiceSelect.appendChild(option)

        // Select default voice
        if (state.selectedVoice && voice.name === state.selectedVoice) {
          elements.ttsVoiceSelect.value = index
        }
      })
    }

    // Chrome needs to wait for the voiceschanged event
    if (state.speechSynthesis.onvoiceschanged !== undefined) {
      state.speechSynthesis.onvoiceschanged = loadVoices
    }

    // Initial load
    loadVoices()
  } else {
    elements.ttsToggle.style.display = "none"
    elements.ttsSpeedContainer.style.display = "none"
    elements.ttsEnabledToggle.parentElement.parentElement.style.display = "none"
  }
}

function speakText(text) {
  if (!state.ttsEnabled || !window.speechSynthesis) return

  // Cancel any ongoing speech
  state.speechSynthesis.cancel()

  // Strip HTML and code blocks for better speech
  const tempDiv = document.createElement("div")
  tempDiv.innerHTML = text
  let cleanText = tempDiv.textContent

  // Remove code blocks for better speech
  cleanText = cleanText.replace(/```[\s\S]*?```/g, "code block omitted for speech")

  const utterance = new SpeechSynthesisUtterance(cleanText)

  // Set voice
  if (state.voices.length > 0) {
    const voiceIndex = Number.parseInt(elements.ttsVoiceSelect.value)
    if (!isNaN(voiceIndex) && voiceIndex >= 0 && voiceIndex < state.voices.length) {
      utterance.voice = state.voices[voiceIndex]
    }
  }

  // Set speech properties
  utterance.rate = state.ttsSpeed
  utterance.pitch = state.ttsPitch

  state.speechSynthesis.speak(utterance)
}

// Modal Functions
function openModal(modal) {
  modal.classList.add("show")
  document.body.style.overflow = "hidden"
}

function closeModal(modal) {
  modal.classList.remove("show")
  document.body.style.overflow = ""
}

function closeAllModals() {
  document.querySelectorAll(".modal").forEach((modal) => {
    closeModal(modal)
  })
}

// File Upload Functions
function handleFileUpload(files) {
  if (!files || files.length === 0) return

  for (const file of files) {
    // Check if file is already in the list
    if (state.fileList.some((f) => f.name === file.name && f.size === file.size)) {
      continue
    }

    // Add file to state
    state.fileList.push(file)

    // Add file to UI
    const fileItem = document.createElement("div")
    fileItem.className = "file-item"
    fileItem.innerHTML = `
      <div class="file-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
          <polyline points="14 2 14 8 20 8"></polyline>
        </svg>
      </div>
      <div class="file-info">
        <div class="file-name">${file.name}</div>
        <div class="file-size">${formatFileSize(file.size)}</div>
      </div>
      <button class="remove-file-btn" data-file="${file.name}">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 6 6 18"></path>
          <path d="m6 6 12 12"></path>
        </svg>
      </button>
    `

    elements.fileList.appendChild(fileItem)

    // Add event listener to remove button
    fileItem.querySelector(".remove-file-btn").addEventListener("click", () => {
      removeFile(file.name)
    })
  }
}

function removeFile(fileName) {
  // Remove from state
  state.fileList = state.fileList.filter((file) => file.name !== fileName)

  // Remove from UI
  const fileItem = elements.fileList.querySelector(`[data-file="${fileName}"]`).closest(".file-item")
  elements.fileList.removeChild(fileItem)
}

function formatFileSize(size) {
  if (size < 1024) {
    return size + " B"
  } else if (size < 1024 * 1024) {
    return (size / 1024).toFixed(1) + " KB"
  } else {
    return (size / (1024 * 1024)).toFixed(1) + " MB"
  }
}

function clearFileList() {
  state.fileList = []
  elements.fileList.innerHTML = ""
}

// Theme and Appearance Functions
function setTheme(theme) {
  document.body.className = state.darkMode ? `dark theme-${theme}` : `theme-${theme}`
  localStorage.setItem("theme", theme)
  state.theme = theme

  // Update active theme in settings
  elements.colorThemes.forEach((themeEl) => {
    if (themeEl.dataset.theme === theme) {
      themeEl.classList.add("active")
    } else {
      themeEl.classList.remove("active")
    }
  })
}

function toggleDarkMode() {
  state.darkMode = !state.darkMode
  document.body.classList.toggle("dark", state.darkMode)
  localStorage.setItem("darkMode", state.darkMode)

  // Update toggle in settings
  elements.darkModeToggle.checked = state.darkMode
}

function setFontSize(size) {
  document.documentElement.style.setProperty("--font-size-base", `${size}px`)
  localStorage.setItem("fontSize", size)
  state.fontSize = size
}

function toggleCompactMode() {
  state.compactMode = !state.compactMode
  document.body.classList.toggle("compact-mode", state.compactMode)
  localStorage.setItem("compactMode", state.compactMode)

  // Update toggle in settings
  elements.compactModeToggle.checked = state.compactMode
}

function toggleAnimations() {
  state.animationsEnabled = !state.animationsEnabled
  document.documentElement.style.setProperty("--transition-normal", state.animationsEnabled ? "0.3s ease" : "0s")
  document.documentElement.style.setProperty("--transition-fast", state.animationsEnabled ? "0.15s ease" : "0s")
  localStorage.setItem("animationsEnabled", state.animationsEnabled)

  // Update toggle in settings
  elements.animationsToggle.checked = state.animationsEnabled
}

// Event Handlers
async function handleSendMessage() {
  const message = elements.userInput.value.trim()
  if (!message) return

  // Add user message to UI
  state.messages.push({
    role: "user",
    content: message,
    timestamp: new Date().toISOString(),
  })

  renderMessages()

  // Clear input
  elements.userInput.value = ""
  elements.userInput.style.height = "auto"
  elements.sendBtn.disabled = true

  // Show typing indicator
  showTypingIndicator()

  // Get AI response
  try {
    const response = await sendMessage(message)

    // Remove typing indicator
    removeTypingIndicator()

    // Add AI message to UI
    state.messages.push({
      role: "assistant",
      content: response,
      timestamp: new Date().toISOString(),
    })

    renderMessages()

    // Speak response if TTS is enabled
    if (state.ttsEnabled) {
      speakText(response)
    }

    // Update chat history
    loadChatHistory()

    // Update chat title if this is the first message
    if (state.messages.length === 2) {
      document.querySelector(".chat-title").textContent = message.substring(0, 30) + (message.length > 30 ? "..." : "")
    }
  } catch (error) {
    // Remove typing indicator
    removeTypingIndicator()
    console.error("Error getting response:", error)
    showToast("Error", "Failed to get response. Please try again.", "error")
  }
}

// Event Listeners
function setupEventListeners() {
  // Send message on enter
  elements.userInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      if (!elements.sendBtn.disabled) {
        handleSendMessage()
      }
    }
  })

  // Auto-resize textarea
  elements.userInput.addEventListener("input", () => {
    elements.userInput.style.height = "auto"
    elements.userInput.style.height = elements.userInput.scrollHeight + "px"

    // Enable/disable send button
    elements.sendBtn.disabled = !elements.userInput.value.trim()
  })

  // Send button
  elements.sendBtn.addEventListener("click", handleSendMessage)

  // New chat button
  elements.newChatBtn.addEventListener("click", startNewChat)

  // Toggle sidebar
  elements.toggleSidebarBtn.addEventListener("click", () => {
    elements.sidebar.classList.toggle("show")
  })

  // Theme toggle
  elements.themeToggle.addEventListener("click", toggleDarkMode)

  // Voice input
  elements.voiceBtn.addEventListener("click", () => {
    if (!state.recognition) return

    if (state.isListening) {
      state.recognition.stop()
    } else {
      state.recognition.start()
    }
  })

  // TTS toggle
  elements.ttsToggle.addEventListener("click", () => {
    state.ttsEnabled = !state.ttsEnabled
    elements.ttsToggle.classList.toggle("active", state.ttsEnabled)
    elements.ttsSpeedContainer.style.display = state.ttsEnabled ? "flex" : "none"
    localStorage.setItem("ttsEnabled", state.ttsEnabled)

    // Update toggle in settings
    elements.ttsEnabledToggle.checked = state.ttsEnabled

    // Cancel any ongoing speech if disabled
    if (!state.ttsEnabled) {
      state.speechSynthesis.cancel()
    }
  })

  // TTS speed slider
  elements.ttsSpeed.addEventListener("input", () => {
    state.ttsSpeed = Number.parseFloat(elements.ttsSpeed.value)
    elements.ttsSpeedValue.textContent = state.ttsSpeed.toFixed(1) + "x"
    localStorage.setItem("ttsSpeed", state.ttsSpeed)

    // Update slider in settings
    elements.ttsSpeedSetting.value = state.ttsSpeed
    elements.ttsSpeedSettingValue.textContent = state.ttsSpeed.toFixed(1) + "x"
  })

  // User menu
  elements.userMenuBtn.addEventListener("click", (e) => {
    e.stopPropagation()
    elements.userDropdown.classList.toggle("show")
  })

  // Close dropdowns when clicking outside
  document.addEventListener("click", () => {
    if (elements.userDropdown.classList.contains("show")) {
      elements.userDropdown.classList.remove("show")
    }
  })

  // Upload button
  elements.uploadBtn.addEventListener("click", () => {
    openModal(elements.fileModal)
  })

  // File input
  elements.fileInput.addEventListener("change", () => {
    handleFileUpload(elements.fileInput.files)
  })

  // File drop area
  elements.fileDropArea.addEventListener("click", () => {
    elements.fileInput.click()
  })

  // Drag and drop for files
  elements.fileDropArea.addEventListener("dragover", (e) => {
    e.preventDefault()
    elements.fileDropArea.style.borderColor = "var(--accent-color)"
  })

  elements.fileDropArea.addEventListener("dragleave", () => {
    elements.fileDropArea.style.borderColor = ""
  })

  elements.fileDropArea.addEventListener("drop", (e) => {
    e.preventDefault()
    elements.fileDropArea.style.borderColor = ""
    handleFileUpload(e.dataTransfer.files)
  })

  // Upload modal buttons
  elements.confirmUploadBtn.addEventListener("click", () => {
    // TODO: Actually upload files to backend
    closeModal(elements.fileModal)
    showToast("Success", "Files uploaded successfully.", "success")

    // Append file info to input
    const fileNames = state.fileList.map((file) => file.name).join(", ")
    if (fileNames) {
      elements.userInput.value += `\n\nUploaded files: ${fileNames}`
      elements.userInput.style.height = "auto"
      elements.userInput.style.height = elements.userInput.scrollHeight + "px"
      elements.sendBtn.disabled = false
    }

    clearFileList()
  })

  elements.cancelUploadBtn.addEventListener("click", () => {
    closeModal(elements.fileModal)
    clearFileList()
  })

  // Settings button
  elements.settingsBtn.addEventListener("click", () => {
    openModal(elements.settingsModal)
  })

  // Settings tabs
  elements.settingsTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      // Update active tab
      elements.settingsTabs.forEach((t) => t.classList.remove("active"))
      tab.classList.add("active")

      // Show corresponding panel
      const panelId = tab.dataset.tab + "-panel"
      elements.settingsPanels.forEach((panel) => panel.classList.remove("active"))
      document.getElementById(panelId).classList.add("active")
    })
  })

  // Settings controls
  elements.darkModeToggle.addEventListener("change", toggleDarkMode)

  elements.colorThemes.forEach((theme) => {
    theme.addEventListener("click", () => {
      setTheme(theme.dataset.theme)
    })
  })

  elements.fontSizeIncrease.addEventListener("click", () => {
    setFontSize(Math.min(state.fontSize + 1, 24))
  })

  elements.fontSizeDecrease.addEventListener("click", () => {
    setFontSize(Math.max(state.fontSize - 1, 12))
  })

  elements.fontSizeReset.addEventListener("click", () => {
    setFontSize(16)
  })

  elements.animationsToggle.addEventListener("change", toggleAnimations)
  elements.compactModeToggle.addEventListener("change", toggleCompactMode)

  elements.ttsEnabledToggle.addEventListener("change", () => {
    state.ttsEnabled = elements.ttsEnabledToggle.checked
    elements.ttsToggle.classList.toggle("active", state.ttsEnabled)
    elements.ttsSpeedContainer.style.display = state.ttsEnabled ? "flex" : "none"
    localStorage.setItem("ttsEnabled", state.ttsEnabled)

    // Cancel any ongoing speech if disabled
    if (!state.ttsEnabled) {
      state.speechSynthesis.cancel()
    }
  })

  elements.ttsVoiceSelect.addEventListener("change", () => {
    const voiceIndex = Number.parseInt(elements.ttsVoiceSelect.value)
    if (!isNaN(voiceIndex) && voiceIndex >= 0 && voiceIndex < state.voices.length) {
      state.selectedVoice = state.voices[voiceIndex].name
      localStorage.setItem("selectedVoice", state.selectedVoice)
    }
  })

  elements.ttsSpeedSetting.addEventListener("input", () => {
    state.ttsSpeed = Number.parseFloat(elements.ttsSpeedSetting.value)
    elements.ttsSpeedSettingValue.textContent = state.ttsSpeed.toFixed(1) + "x"
    elements.ttsSpeed.value = state.ttsSpeed
    elements.ttsSpeedValue.textContent = state.ttsSpeed.toFixed(1) + "x"
    localStorage.setItem("ttsSpeed", state.ttsSpeed)
  })

  elements.ttsPitch.addEventListener("input", () => {
    state.ttsPitch = Number.parseFloat(elements.ttsPitch.value)
    elements.ttsPitchValue.textContent = state.ttsPitch.toFixed(1) + "x"
    localStorage.setItem("ttsPitch", state.ttsPitch)
  })

  elements.voiceInputToggle.addEventListener("change", () => {
    if (elements.voiceInputToggle.checked) {
      // Request microphone permission
      navigator.mediaDevices
        .getUserMedia({ audio: true })
        .then(() => {
          elements.voiceBtn.style.display = "flex"
        })
        .catch(() => {
          elements.voiceInputToggle.checked = false
          showToast("Error", "Microphone access denied. Please check your browser settings.", "error")
        })
    } else {
      elements.voiceBtn.style.display = "none"
      if (state.isListening && state.recognition) {
        state.recognition.stop()
      }
    }
  })

  // Clear context button
  elements.clearContextBtn.addEventListener("click", () => {
    // Keep only the latest user message and AI response
    if (state.messages.length > 2) {
      state.messages = state.messages.slice(-2)
      renderMessages()
      showToast("Success", "Context cleared successfully.", "success")
    } else {
      showToast("Info", "No context to clear.", "info")
    }
  })

  // Share button
  elements.shareBtn.addEventListener("click", () => {
    // Generate share link
    const shareLink = `${window.location.origin}/chat/${state.currentChatId}`
    elements.shareLink.value = shareLink

    openModal(elements.shareModal)
  })

  // Copy share link
  elements.copyShareLink.addEventListener("click", () => {
    navigator.clipboard
      .writeText(elements.shareLink.value)
      .then(() => {
        showToast("Success", "Link copied to clipboard.", "success")
      })
      .catch(() => {
        showToast("Error", "Failed to copy link.", "error")
      })
  })

  // Export button
  elements.exportBtn.addEventListener("click", () => {
    openModal(elements.exportModal)
  })

  // Export functionality
  elements.confirmExportBtn.addEventListener("click", () => {
    const format = document.querySelector(".export-option.active")?.id.replace("export-", "") || "json"
    const chatSelection = elements.exportChatSelect.value
    const includeCode = elements.exportIncludeCode.checked

    exportChat(format, chatSelection, includeCode)
    closeModal(elements.exportModal)
  })

  elements.exportOptions.forEach((option) => {
    option.addEventListener("click", () => {
      elements.exportOptions.forEach((o) => o.classList.remove("active"))
      option.classList.add("active")
    })
  })

  // Clear all data
  elements.clearDataBtn.addEventListener("click", () => {
    if (confirm("Are you sure you want to clear all data? This action cannot be undone.")) {
      localStorage.clear()
      showToast("Success", "All data cleared. The page will reload.", "success")
      setTimeout(() => {
        window.location.reload()
      }, 2000)
    }
  })

  // Close modal buttons
  elements.closeModalBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      closeAllModals()
    })
  })

  // Close modals with escape key
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      closeAllModals()
    }
  })

  // Suggestion chips
  elements.suggestionChips.forEach((chip) => {
    chip.addEventListener("click", () => {
      elements.userInput.value = chip.textContent
      elements.userInput.focus()
      elements.userInput.dispatchEvent(new Event("input"))
    })
  })
}

// Export Functions
function exportChat(format, chatSelection, includeCode) {
  let data

  if (chatSelection === "current") {
    data = state.messages
  } else {
    // TODO: Fetch all chats from backend
    showToast("Info", "Exporting all chats is not implemented yet.", "info")
    return
  }

  if (!data || data.length === 0) {
    showToast("Error", "No data to export.", "error")
    return
  }

  let content = ""
  let filename = `chat-${state.currentChatId.slice(0, 8)}-${new Date().toISOString().slice(0, 10)}`

  switch (format) {
    case "json":
      content = JSON.stringify(data, null, 2)
      filename += ".json"
      break

    case "markdown":
      content = data
        .map((message) => {
          const role = message.role === "user" ? "User" : "Assistant"
          const timestamp = new Date(message.timestamp).toLocaleString()
          let msgContent = message.content

          if (!includeCode) {
            msgContent = msgContent.replace(/```[\s\S]*?```/g, "```\nCode block omitted in export\n```")
          }

          return `## ${role} - ${timestamp}\n\n${msgContent}\n\n---\n\n`
        })
        .join("")
      filename += ".md"
      break

    case "html":
      content = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Chat Export</title>
  <style>
    body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
    .message { margin-bottom: 20px; padding: 10px; border-radius: 5px; }
    .user { background-color: #f0f0f0; }
    .assistant { background-color: #e1f5fe; }
    .timestamp { font-size: 12px; color: #888; margin-bottom: 5px; }
    pre { background-color: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
    code { font-family: monospace; }
  </style>
</head>
<body>
  <h1>Chat Export</h1>
  ${data
    .map((message) => {
      const role = message.role === "user" ? "User" : "Assistant"
      const timestamp = new Date(message.timestamp).toLocaleString()
      let msgContent = message.content

      if (!includeCode) {
        msgContent = msgContent.replace(/```[\s\S]*?```/g, "<pre><code>Code block omitted in export</code></pre>")
      } else {
        msgContent = msgContent.replace(/```(\w+)?\n([\s\S]*?)\n```/g, "<pre><code>$2</code></pre>")
      }

      // Basic markdown conversion
      msgContent = msgContent
        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
        .replace(/\*(.*?)\*/g, "<em>$1</em>")
        .replace(/\n/g, "<br>")

      return `
  <div class="message ${message.role}">
    <div class="timestamp">${role} - ${timestamp}</div>
    <div class="content">${msgContent}</div>
  </div>`
    })
    .join("")}
</body>
</html>`
      filename += ".html"
      break

    default:
      showToast("Error", "Invalid export format.", "error")
      return
  }

  // Create download link
  const blob = new Blob([content], { type: "text/plain" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)

  showToast("Success", `Chat exported as ${format.toUpperCase()} successfully.`, "success")
}

// Load Chat History
async function loadChatHistory() {
  const chats = await fetchChats()
  updateChatHistory(chats)
}

// Initialize App
function initApp() {
  // Apply saved settings
  if (state.darkMode) {
    document.body.classList.add("dark")
  }

  setTheme(state.theme)
  setFontSize(state.fontSize)

  if (state.compactMode) {
    document.body.classList.add("compact-mode")
  }

  // TTS settings
  elements.ttsToggle.classList.toggle("active", state.ttsEnabled)
  elements.ttsSpeedContainer.style.display = state.ttsEnabled ? "flex" : "none"
  elements.ttsSpeed.value = state.ttsSpeed
  elements.ttsSpeedValue.textContent = state.ttsSpeed.toFixed(1) + "x"

  // Initialize speech recognition if available
  initSpeechRecognition()

  // Initialize text-to-speech if available
  initTextToSpeech()

  // Set up tooltips
  const tippy = window.tippy // Declare tippy variable
  tippy("[data-tippy-content]", {
    theme: "light",
    placement: "bottom",
  })

  // Set up form controls in settings
  elements.darkModeToggle.checked = state.darkMode
  elements.animationsToggle.checked = state.animationsEnabled
  elements.compactModeToggle.checked = state.compactMode
  elements.ttsEnabledToggle.checked = state.ttsEnabled
  elements.ttsSpeedSetting.value = state.ttsSpeed
  elements.ttsSpeedSettingValue.textContent = state.ttsSpeed.toFixed(1) + "x"
  elements.ttsPitch.value = state.ttsPitch
  elements.ttsPitchValue.textContent = state.ttsPitch.toFixed(1) + "x"

  // Load chat history
  loadChatHistory()

  // Set up event listeners
  setupEventListeners()

  // Initialize welcome message
  renderMessages()
}

// Start the application
document.addEventListener("DOMContentLoaded", initApp)

